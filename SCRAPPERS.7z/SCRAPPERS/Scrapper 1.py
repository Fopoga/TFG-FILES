# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 17:43:02 2024

@author: Gabriel
"""

#1/ 00_Descarga_links_municipios.py à con este, descargamos las urls de los códigos postales de cada provincia

 

# -*- coding: iso-8859-1 -*-

"""

Created on Fri Mar  1 14:05:12 2024

 

"""

 

# Import modules

import os

import io

import json

from bs4 import BeautifulSoup

import requests

import re

 

 

HEADERS = ({'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',  'Accept-Language': 'en-US, en;q=0.5'})

 

 

fichero = 'municipios.txt'

 

#url = 'https://realadvisor.es/es/precios-viviendas/provincia-madrid'

 

## Arbimos le fichero para descargar los datos

prov = ["madrid", "barcelona", "valencia", "sevilla", "alacant", "malaga", "murcia", "cadiz", "vizcaya", "baleares",
    "la coruna", "las palmas", "asturias", "santa cruz de tenerife", "zaragoza", "pontevedra", "granada", "tarragona",
    "cordoba", "gerona", "guipuzcoa", "almeria", "toledo", "badajoz", "navarra", "jaen", "cantabria", "castello",
    "valladolid", "huelva", "ciudad real", "leon", "lerida", "caceres", "albacete", "burgos", "lugo", "salamanca",
    "araba", "la rioja", "ourense", "guadalajara", "huesca", "cuenca", "zamora", "palencia", "avila", "segovia",
    "teruel", "soria", "melilla", "ceuta"
]
urls = ['https://realadvisor.es/es/precios-viviendas/provincia-' + provincia for provincia in prov]


with io.open(fichero, "w", encoding="iso-8859-1") as f:
    
    for url in urls:
        
        response = requests.get(url, headers=HEADERS)

        

        #print(response.encoding)

        #soup = BeautifulSoup(webpage.content, "html.parser")

        html = BeautifulSoup(response.text, 'html.parser', from_encoding="iso-8859-1")

        datos1 = html.find('div',  {"class": "flex flex-col w-full rounded-md border border-black/25 border-solid overflow-auto"})

        regex = re.compile('body2 border-b*')

        datos2 = html.find_all('tr', {"class": regex})

       

        for i in range(0, len(datos2)):

            datos3 = datos2[i].find_all('td')

            Municipio = ''

            Piso = ''

            Casa = ''

            Renta = ''

            Población = ''

            link = ''

           

            if datos3[0] is not None:

                Municipio = datos3[0].text.encode("iso-8859-1").decode("utf-8")

                link = [a['href'] for a in datos3[0].find_all('a', href=True) if a.text][0]

            if datos3[1] is not None:

                Piso = datos3[1].text

            if datos3[2] is not None:

                Casa = datos3[2].text

            if datos3[3] is not None:

                Renta = datos3[3].text

            if datos3[4] is not None:

                Población = datos3[4].text.replace('.', '')

           

            todo = Municipio + "|" + Piso  + "|" + Casa + "|" + Renta  + "|" + Población + "|" + link

            todo = todo.replace('\rn', '').replace('\t', '').replace('\f', '').replace('\n', '').replace('Â', '').replace('â‚¬', '').strip()

            print(todo)

            f.write(todo)

            f.write('\n')